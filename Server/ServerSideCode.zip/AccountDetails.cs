﻿namespace Server
{
    public class AccountDetails
    {
        public AccountDetails()
        {

        }
    }
}